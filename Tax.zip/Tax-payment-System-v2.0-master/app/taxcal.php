<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class taxcal extends Model
{
    //
}
